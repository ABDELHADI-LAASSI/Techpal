This module hides sales orders and quotations in the customer portal home page.
